package forgottenBattleships.core;

import forgottenBattleships.entities.battlezone.BattleZone;

public class ControllerImpl implements Controller{

    //TODO Implement all the methods below

    @Override
    public String addBattleZone(String battleZoneName, int capacity) {
        return null;
    }

    @Override
    public BattleZone getBattleZoneByName(String battleZoneName) {
        return null;
    }

    @Override
    public String addBattleshipToBattleZone(String battleZoneName, String shipType, String shipName, int health) {
        return null;
    }

    @Override
    public String startBattle(String battleZoneName, String attackingShip, String shipUnderAttack) {
        return null;
    }

    @Override
    public String getStatistics() {
        return null;
    }
}
