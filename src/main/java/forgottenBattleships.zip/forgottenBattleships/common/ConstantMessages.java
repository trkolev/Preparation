package forgottenBattleships.common;

public class ConstantMessages {

    public static final String SUCCESSFULLY_ADDED_BATTLE_ZONE = "Successfully added %s battle zone.";
    public static final String SUCCESSFULLY_ADDED_SHIP = "Successfully added %s %s to %s battle zone.";
    public static final String SHIP_WINS = "%s is the only one who survived and won the battle!";
    public static final String BATTLE_CONTINUES = "The battle in %s continues. Ships still in battle: ";
    public static final String SHIPS_IN_BATTLE_ZONE = "Ships in %s battle zone: ";
    public static final String SHIP_INFO = "-- %s - health: %d, ammunition: %d";





}

